---
layout: post
title: 已开源的项目
categories: [开源]
tags: [开源]
fullview: true
---

## Hilo

![](http://gtms04.alicdn.com/tps/i4/TB1IvTTLVXXXXb7XFXXLP9XYVXX-208-113.png)

[Hilo](https://github.com/hiloteam/Hilo)，一套HTML5跨终端的互动游戏解决方案。Hilo支持了多届淘宝&天猫狂欢城等双十一大型和日常营销活动。内核极简，提供包括DOM，Canvas，Flash，WebGL等多种渲染方案，满足全终端和性能要求。支持多种模块范式的包装版本以及开放的扩展方式，方便接入和扩展。提供对2D物理，骨骼动画的内建和扩展支持。另外，Hilo提供丰富的周边工具及开发案例。

目前，Hilo已经开源，并入到Hilo Team中。[开源地址](https://github.com/hiloteam/Hilo)（欢迎Star）