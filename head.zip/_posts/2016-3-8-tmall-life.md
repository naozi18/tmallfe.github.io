---
layout: post
title: 在天猫担任前端工程师是一种什么样的体验
categories: [加入天猫]
tags: [加入天猫]
fullview: true
---

知乎上的讨论：[在天猫担任前端工程师是一种什么样的体验](https://www.zhihu.com/question/33589154)

对加入天猫前端团队有意向的，可以发简历到join-tmallfe@list.alibaba-inc.com，[招聘要求](https://job.alibaba.com/zhaopin/position_detail.htm?positionId=3504)